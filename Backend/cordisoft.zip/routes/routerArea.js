import express from 'express'

const rutasArea= express.Router()

import { crearArea } from '../controllers/controllerArea.js'
rutasArea.post('/crear',crearArea)

import { listarArea } from '../controllers/controllerArea.js'
rutasArea.get('/listar',listarArea)

import { editarArea } from '../controllers/controllerArea.js'
rutasArea.put('/editar/:id',editarArea)

import { eliminarArea } from '../controllers/controllerArea.js'
rutasArea.delete('/eliminar/:id',eliminarArea)

import { buscarArea } from '../controllers/controllerArea.js'
rutasArea.get('/buscar/:id',buscarArea)


export default rutasArea;