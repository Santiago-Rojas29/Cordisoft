import express from 'express'
import bodyParser from 'body-parser'
import cors from 'cors'

const servidor = express();

servidor.use(bodyParser.json())
servidor.use(cors())

import rutasArea from './routes/routerArea.js';
servidor.use('/areas',rutasArea)





servidor.listen(3000,()=>{
    console.log("Servidor corriendo en el puerto 3000")

})
